<?xml version="1.0" encoding="utf-8"?>
<!--
Run the update_translations CMake target to populate the source strings in this file.
-->
<!DOCTYPE TS>
<TS version="2.1" language="en_AS" sourcelanguage="en"/>
